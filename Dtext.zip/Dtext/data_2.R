library(stringr); library(tidyr); library(visNetwork)

email_feed <- all_check[,c("User", "From", "To", "Subject", "Date",
                           "is_suspiscius", "bodies", "username_to", "username_from")]
names_from <- unique(email_feed$username_from)
names_to <- unique(email_feed$username_to)

inter_from_to <- intersect(names_from, names_to)

# not in the list:
not_in_the_list <- c("andrew.fastow", "jeffrey.mcahon", 
                     "jeffrey.skilling", "kenneth.lay",
                     "robert.bennet")

nombres <- c(inter_from_to, not_in_the_list)

nombres_1 <- str_split(nombres, "[.]", simplify = TRUE)

nombres_1 <- cbind(nombres, nombres_1)

nombres_1 <- nombres_1[nombres_1[,3] != "",]


write.csv2(nombres_1, file = "people_enron.csv", append = T)


data1 <- head(email_suspiscious[,-c(6,7,8,9)])

data1 <- data1[,-1]
data1 <- data1[,c(1,2,4,3)]
data1[,5] <- NA
colnames(data1) <- c("From", "To", "Time", "Subject", "Status")
data1[1,1] <- "marlene.olivares@gmail.com"
data1[1,2] <- "sebastian.pineda@yahoo.es"
data1[1,3] <- "08:03 am 10/17/2018"
data1[1,4] <- "Q3 Results"
data1[1,5] <- "Suspicious"

data1[2,1] <- "charles.mcgill@hhm.com"
data1[2,2] <- "howard.hamlin@hhm.com"
data1[2,3] <- "09:14 pm 10/17/2018"
data1[2,4] <- "The eagle has landed"
data1[2,5] <- "Suspicious"

email_feed_day1 <- data1[1:2,]
save(email_feed_day1, file = "data/email_feed_day1.RData")

data2 <- email_suspiscious[1,]
data2[,"sus_value"] <- "67"
data2[2,"sus_value"] <- "78"
data2[1, "Subject"] <- "Q3 Results"
data2[1, "Role_From"] <- "Accountant"
data2[1, "DOJ_From"] <- "03-05-2014"
data2[1, "bodies"] <- "Hi Sebastian:

I reviewed your sales report from previous month and I noticed some special fees that don’t seem right. I looked back at previous report and saw a pattern that I think we should talk about. I’m sure is nothing but it’s worth talking about.

Thanks!
"
data2[1, "name_from"] <- "Marlene Olivares"
data2[1, "name_to"] <- "Sebastian Pineda"
data2[1, "Role_To"] <- "Sales Executive"
data2[1, "DOJ_To"] <- "09-17-2015"
data2[1, "pic_from"] <- "Marlene_Olivares"
data2[1, "pic_to"] <- "Sebastian_Pineda"

data2[2, "Subject"] <- "The eagle has landed"
data2[2, "Role_From"] <- "Senior Executive"
data2[2, "DOJ_From"] <- "03-05-2008"
data2[2, "bodies"] <- "Howard

Rachel called and she pulled it off. We still need to figure out what we’ll do with the data but I’m sure we can get rid of it with some of our tech guys as long as the amount is convincing.

Come to my office and we can talk specifics.
"
data2[2, "name_from"] <- "Charles McGill"
data2[2, "name_to"] <- "Howard Hamlin"
data2[2, "Role_To"] <- "Senior Accountant"
data2[2, "DOJ_To"] <- "09-17-2015"
data2[2, "pic_from"] <- "Charles_McGill"
data2[2, "pic_to"] <- "Howard_Hamlin"
data2[2, "manager_from"] <- "Robert_Goodman"
data2[2, "department_from"] <- "Acquisitions"
data2[2, "total_emails_from"] <- "4978"
data2[2, "total_suspicious_emails_from"] <- "4"
data2[2, "most_connected_user_from"] <- "Adrian Martínez (8% of Email Traffic)"
data2[2, "Connectedness_from"] <- "0.48 "
data2[2, "Connectedness_from_summary"] <- "(+0.32% Above Average)"
data2[2, "Betweeness_from"] <- "0.61 "
data2[2, "Betweeness_from_summary"] <- "(+12% Above Average)"
data2[2, "Closeness_from"] <- "0.24 "
data2[2, "Closeness_from_summary"] <- "(-14% Below Average)"

email_feed_day1_detail <- data2
save(email_feed_day1_detail, file = "data/email_feed_day1_detail.RData")

str(email_suspiscious[1,])

email_feed_second_day <- as.data.frame(NA)
email_feed_second_day[1, "From"] <- "Marcelo.urrutia@gmail.com"
email_feed_second_day[2, "From"] <- "Carlos.fernandez@gmail.com"

email_feed_second_day[1, "To"] <- "Adolfo.munoz@hotmail.com"
email_feed_second_day[2, "To"] <- "Loreto.arancibia@gmail.com"

email_feed_second_day[1, "Time"] <- "9:45 am 10/19/2018"
email_feed_second_day[2, "Time"] <- "11:58 am 10/19/2018"

email_feed_second_day[1, "Title"] <- "Are you sure about this?"
email_feed_second_day[2, "Title"] <- "Looks good to me"

email_feed_second_day[1, "Status"] <- "Suspicious"
email_feed_second_day[2, "Status"] <- "Suspicious"
