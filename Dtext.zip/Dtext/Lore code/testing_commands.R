library(shiny); library(shinydashboard); library(shinythemes); library(stringr)
library(DT); library(dplyr); library(magrittr); library(RMySQL); library(shinyjs) ; 
library(RDCOMClient); library(visNetwork); library(shinyWidgets)

#install.packages(c("shinydashboard", "shinythemes", "DT", "magrittr", "RMySQL", "shinyjs", "visNetwork"))

email_txt_path <- dirname(rstudioapi::getSourceEditorContext()$path)

load(paste0(email_txt_path, "/data/enron_training.RData"))

load(paste0(email_txt_path, "/data/email_feed_day1.RData"))
load(paste0(email_txt_path, "/data/email_feed_day1_detail.RData"))
# load(paste0(email_txt_path, "/data/data.RData"))
load(paste0(email_txt_path, "/data/class_mails.RData"))
load(paste0(email_txt_path, "/data/viz.RData"))

Previus_suspicious <- read.csv(paste0(email_txt_path,"/data/Previus_suspicious.csv"))


dictionary_2 <- read.csv2(paste0(email_txt_path, "/data/Fraud Keyword Dictionary WIP.csv"), header = FALSE,
                          stringsAsFactors = FALSE)

email_feed <- class_mails[,c("User", "From", "To", "Subject", "Date",
                             "is_suspiscius", "bodies", "username_to", "username_from")]

email_suspiscious <- email_feed[email_feed$is_suspiscius == 1 , ]
follow_ups <- class_mails[11:20,]

email_suspiscious$Date <- format(email_suspiscious$Date,
                                 "%H:%M, %a, %b %d")

follow_ups <- email_feed[11:20,]

# To have different Emails acording to the day

email_feed$Date <- as.Date(email_feed$Date, format="%H:%M, %a, %b %d")
email_feed <- dplyr::arrange(email_feed, Date)

start_date = as.Date("2018-08-12")
time_difference = as.integer(Sys.Date() - start_date)
set.seed(as.integer(Sys.Date()))
num_cho = floor(runif(1, 3,15)) 

emails_day = email_feed[(9*time_difference):(9*time_difference+num_cho),]
email_suspiscious_1 <- email_feed[email_feed$is_suspiscius ==1, ][2,]
email_suspiscious = rbind(emails_day, email_suspiscious_1)
email_suspiscious <- dplyr::arrange(email_suspiscious, desc(is_suspiscius))

dictionary_1 <- as.data.frame(c('lawyers', 'voice mail', 'stalking', 'special fees', 'dont seem right',
                                'get rid of it', 'amount is convincing'))
colnames(dictionary_1) <- c('V1')
dictionary <- rbind(dictionary_2, dictionary_1)
dictionary <- as.character(dictionary$V1)

sus_value <- 87

str(nodes)

edge <- data %>% filter(id_f == 1 | id_t == 1)
node <- tibble(id = union(unique(edge$id_f), unique(edge$id_t)))
node <- left_join(node, nodes)
second_level <- node %>% filter(id != 1)
second_level_edges <- filter(data, id_f %in% second_level$id, is_s == 1)
sec_edge <- rbind(second_level_edges, edge)
node <- tibble(id = union(unique(sec_edge$id_f), unique(sec_edge$id_t)))
node <- left_join(node, nodes)
#Ordering and changing color
aux <- node %>% filter(nodos == "Charles McGill")
auxC <- node %>% filter(nodos != "Charles McGill")


nododos <- data.frame(id = as.integer(nodes$id),
                      label = nodes$nodos)

edgeges <- data.frame(from = data$id_f, to = data$id_t, is_s = data$is_s, color = data$color)

edgeges <- edgeges[order(edgeges$is_s, decreasing = TRUE), ]

edges0 <- edgeges %>% group_by(from, to) %>% summarise(value=n())

edges1 <- distinct(edgeges, from, to, .keep_all = T)

edges3 <- as.data.frame(merge(edges1,edges0))

#data2 <- data2[seq(dim(data2)[1],1),]
#email_feed_day1 <- email_feed_day1[seq(dim(email_feed_day1)[1],1),]

#Filtering the social network by worker
id_selected <- 1
edge <- edges3 %>%  filter(id_selected == from | id_selected == to)
node <- data.frame(id=union(unique(edge$from),unique(edge$to)))
node <- left_join(node,nododos)
second_level <- node[!(node$id == id_selected),]
second_level_edges <- filter(edges3,from %in% second_level$id)
second_level_edges <- second_level_edges[!(second_level_edges$is_s == 0),]
sec_edge <- rbind(second_level_edges,edge)
node <- data.frame(id=union(unique(sec_edge$from),unique(sec_edge$to)))
node <- left_join(node,nododos) %>% unique()
# aux <- node %>%  filter("Charles McGill" == nodos)
# auxC <- node %>%  filter("Charles McGill" != nodos)
# node<- rbind(aux,auxC) %>% data.frame(color=sapply("lightBlue", function (x) rep(x,nrow(node)-1)) %>% rbind("pink", .) %>% as.vector() )
# 

email_follow_ups <- email_feed_day1[-length(email_feed_day1), ]

email_follow_ups <- email_follow_ups[-1, ]

glimpse(email_feed_day1)
View(email_feed_day1)

email_feed_day1$'Suspicious Index' <- NA
email_feed_day1$'Suspicious Index'[1] <- 0.78
email_feed_day1$'Suspicious Index'[2] <- 0.62

email_feed_day1 %<>% arrange(desc(`Suspicious Index`))
email_feed_day1 %<>% arrange(`Suspicious Index`)

save(email_follow_ups, file="email_follow_ups.RData")

getwd()data3 <- data2[-1, ]
